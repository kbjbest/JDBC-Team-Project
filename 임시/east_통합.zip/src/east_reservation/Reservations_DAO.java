package east_reservation;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import db.DBConnection;
import east_view.Member_DTO;

public class Reservations_DAO {

	// TODO searchAll : ��ü����
	/**
	 * ������Ȳ�� ���õ� ��� �׸��� ������.
	 * @return ������Ȳ ����Ʈ
	 */
	public ArrayList<Reservations_DTO> searchAll(String isReservation, Member_DTO dto_member) {
		ArrayList<Reservations_DTO> result = new ArrayList<>();

		Connection con = DBConnection.getConnection();
		Statement stmt = null;
		ResultSet rs = null;

		try {
			stmt = con.createStatement();

			String sql = "select m.MemberNO, m.Name, "
					+ "a.PlaneNO, a.PlaneCode, a.PlaneName, "
					+ "r.StartDate, a.StartTime, "
					+ "r.ArrivalDate, a.ArrivalTime, "
					+ "a.StartLoc, a.ArrivalLoc, r.Seat, r.ListNO "
					+ "from TB_RESERVATIONS r, TB_MEMBER m, TB_AVIATIONINFO a "
					+ "where m.MemberNO = r.MemberNO "
					+ ((dto_member != null) ? "and m.MemberNO = " + dto_member.getMemberNO() + " " : "")
					+ "and a.PlaneNO = r.PlaneNO "
					+ "and r.Cancel = '" + (isReservation.equals(Reservations.MODE_CANCEL) ? "y" : "n") + "' "
					+ "order by r.ListNO desc";
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				Reservations_DTO data = new Reservations_DTO();
				data.setMemberNO(rs.getInt(1));
				data.setName(rs.getString(2));
				data.setPlaneNO(rs.getInt(3));
				data.setPlaneCode(rs.getString(4));
				data.setPlaneName(getPlaneInitialToPlaneName(rs.getString(5)));
				data.setStartDate(rs.getDate(6));
				data.setStartTime(rs.getString(7));
				data.setArrivalDate(rs.getDate(8));
				data.setArrivalTime(rs.getString(9));
				data.setStartLoc(rs.getString(10));
				data.setArrivalLoc(rs.getString(11));
				data.setSeat(rs.getString(12));
				data.setListNO(rs.getInt(13));

				result.add(data);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				stmt.close();
			} catch (Exception e) {
			}
		}
		return result;
	}

	// TODO search : ���� �˻�
	/**
	 * ������ ���ؼ� ������Ȳ �׸��� ������.
	 * @param dto : ���ǿ� ����� DTO ��ü
	 * @return ���͸��� ������Ȳ ����Ʈ
	 */
	public ArrayList<Reservations_DTO> search(Reservations_DTO dto) {
		ArrayList<Reservations_DTO> result = new ArrayList<>();
		Connection con = DBConnection.getConnection();
		Statement stmt = null;
		ResultSet rs = null;

		try {
			stmt = con.createStatement();

			String sql = "select m.MemberNO, m.Name, "
					+ "a.PlaneNO, a.PlaneCode, a.PlaneName, "
					+ "r.StartDate, a.StartTime, "
					+ "r.ArrivalDate, a.ArrivalTime, "
					+ "a.StartLoc, a.ArrivalLoc, r.Seat, r.ListNO "
					+ "from TB_RESERVATIONS r, TB_MEMBER m, TB_AVIATIONINFO a ";
			String sql_Where = "where (m.MemberNO = r.MemberNO "
					+ "and a.PlaneNO = r.PlaneNO) "
					+ "and r.Cancel = '" + ((dto.getCancel() == null) ? "n" : dto.getCancel()) + "' ";
			ArrayList<String> arr_Where = new ArrayList<>();
			String sql_Order = " order by r.ListNO desc";

			if (dto.getMemberNO() != 0) {
				arr_Where.add("m.MemberNO = " + dto.getMemberNO());
			}
			if (dto.getName() != null && !dto.getName().equals("")) {
				arr_Where.add("m.Name like '%' || '" + dto.getName() + "' || '%'");
			}
			if (dto.getPlaneName() != null && !dto.getPlaneName().equals("")) {
				arr_Where.add("a.planeName = '" + getPlaneNameToPlaneInitial(dto.getPlaneName()) + "'");
			}
			if (dto.getSeat() != null && !dto.getSeat().equals("")) {
				arr_Where.add("r.Seat = '" + dto.getSeat() + "'");
			}
			if (dto.getStartDate() != null && dto.getArrivalDate() != null) {
				arr_Where.add("(r.StartDate >= '" + dto.getStartDate().toString() + "' and r.ArrivalDate <= '"
						+ dto.getArrivalDate() + "')");
			}
			if (dto.getStartLoc() != null) {
				arr_Where.add("a.StartLoc = '" + dto.getStartLoc() + "'");
			}
			if (dto.getArrivalLoc() != null) {
				arr_Where.add("a.ArrivalLoc = '" + dto.getArrivalLoc() + "'");
			}

			for (int i = 0; i < arr_Where.size(); i++) {
				sql_Where += " and ";
				sql_Where += arr_Where.get(i);
				if (i != arr_Where.size() - 1) {
				}
			}

			String query = sql + sql_Where + sql_Order;
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				Reservations_DTO data = new Reservations_DTO();
				data.setMemberNO(rs.getInt(1));
				data.setName(rs.getString(2));
				data.setPlaneNO(rs.getInt(3));
				data.setPlaneCode(rs.getString(4));
				data.setPlaneName(getPlaneInitialToPlaneName(rs.getString(5)));
				data.setStartDate(rs.getDate(6));
				data.setStartTime(rs.getString(7));
				data.setArrivalDate(rs.getDate(8));
				data.setArrivalTime(rs.getString(9));
				data.setStartLoc(rs.getString(10));
				data.setArrivalLoc(rs.getString(11));
				data.setSeat(rs.getString(12));
				data.setListNO(rs.getInt(13));
				
				result.add(data);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				stmt.close();
			} catch (Exception e) {
			}
		}
		return result;
	}

	// TODO delete : ����
	/**
	 * �����׸� ����
	 * @param dto : ���ǿ� ����� DTO ��ü
	 * @return ���� ���
	 */
	public int delete(Reservations_DTO dto) {
		int result = 0;
		Connection con = DBConnection.getConnection();
		PreparedStatement pstmt = null;

		try {
			String sql = "delete from tb_reservations "
					+ "where ListNO = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, dto.getListNO());

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
			} catch (Exception e) {
			}
		}
		return result;
	}
	
	// TODO update : ����
	/**
	 * �����׸� ����
	 * @param dto : ���ǿ� ����� DTO ��ü
	 * @return ���� ���
	 */
	public int update(Reservations_DTO dto) {
		int result = 0;
		Connection con = DBConnection.getConnection();
		PreparedStatement pstmt = null;
		
		try {
			String sql = "update tb_reservations ";
			if (dto.getCancel().equals("n")) {
				sql += "set MemberNo = ?, PlaneNO = ?, Seat = ?, StartDate = ?, ArrivalDate = ?, Cancel = ? "
						+ "where ListNO = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, dto.getMemberNO());
				pstmt.setInt(2, dto.getPlaneNO());
				pstmt.setString(3, dto.getSeat());
				pstmt.setDate(4, dto.getStartDate());
				pstmt.setDate(5, dto.getArrivalDate());
				pstmt.setString(6, dto.getCancel());
				pstmt.setInt(7, dto.getListNO());
				
			} else if (dto.getCancel().equals("y")) {
				sql += "set Cancel = ? "
						+ "where ListNO = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, dto.getCancel());
				pstmt.setInt(2, dto.getListNO());
				
			}

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
			} catch (Exception e) {
			}
		}
		return result;
	}

	
	// TODO getPlaneInitialToPlaneName : ������̴ϼ� -> ������̸�
	public String getPlaneInitialToPlaneName(String PlaneInitial) {
		String PlaneName = "";

		switch (PlaneInitial) {
		case "A":
			PlaneName = "�ƽþƳ�";
			break;

		case "D":
			PlaneName = "�����װ�";
			break;
			
		case "J":
			PlaneName = "������";
			break;
			
		case "E":
			PlaneName = "���̷���Ʈ";
			break;

		default:
			PlaneName = PlaneInitial;
			break;
		}
		return PlaneName;
	}

	// TODO getPlaneNameToPlaneInitial : ������̸� -> ������̴ϼ�
	public String getPlaneNameToPlaneInitial(String PlaneName) {
		String PlaneInitial = "";

		switch (PlaneName) {
		case "�ƽþƳ�":
			PlaneInitial = "A";
			break;

		case "�����װ�":
			PlaneInitial = "D";
			break;

		case "������":
			PlaneInitial = "J";
			break;
			
		case "���̷���Ʈ":
			PlaneInitial = "E";
			break;
			
		default:
			PlaneInitial = PlaneName;
			break;
		}
		return PlaneInitial;
	}
	
	// TODO getAviationInfo : �װ������� ������
	public ArrayList<Reservations_DTO> getAviationInfo() {
		ArrayList<Reservations_DTO> result = new ArrayList<>();
		Connection con = DBConnection.getConnection();
		Statement stmt = null;
		ResultSet rs = null;

		try {
			stmt = con.createStatement();
			String sql = "select PlaneNO, PlaneCode, PlaneName, StartTime, ArrivalTime, StartLoc, ArrivalLoc "
					+ "from TB_AVIATIONINFO ";
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				Reservations_DTO data = new Reservations_DTO();
				data.setPlaneNO(rs.getInt(1));
				data.setPlaneCode(rs.getString(2));
				data.setPlaneName(getPlaneInitialToPlaneName(rs.getString(3)));
				data.setStartTime(rs.getString(4));
				data.setArrivalTime(rs.getString(5));
				data.setStartLoc(rs.getString(6));
				data.setArrivalLoc(rs.getString(7));

				result.add(data);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				stmt.close();
			} catch (Exception e) {
			}
		}
		return result;
	}
	
	// TODO getAviationList : �װ������� ����Ʈ�� ���
	public ArrayList<String> getAviationList() {
		ArrayList<String> arr_str = new ArrayList<>();
		ArrayList<Reservations_DTO> dto = getAviationInfo();

		for (Reservations_DTO re_dto : dto) {
			arr_str.add("[" + re_dto.getStartTime() + " " + re_dto.getStartLoc() + "] ~ "
					+ "[" + re_dto.getArrivalTime() + " " + re_dto.getArrivalLoc() + "] (" + re_dto.getPlaneCode() + ")");
		}

		return arr_str;
	}
	
	// TODO getPlaneCodeToAviationListItem : �װ����� ����Ʈ�� �ִ� �׸񿡼� ������ڵ带 ����
	public String getPlaneCodeToAviationListItem(String aviationListItem) {
		return aviationListItem.substring(aviationListItem.lastIndexOf("(") + 1, aviationListItem.length() - 1);
	}
	
	// TODO getPlaneNoToPlaneCode : ������ڵ带 ������ȣ�� ��ȯ
	public int getPlaneNoToPlaneCode(String planeCode) {
		int result = 0;
		ArrayList<Reservations_DTO> dto = getAviationInfo();
		
		for (Reservations_DTO re_dto : dto) {
			if (re_dto.getPlaneCode().equals(planeCode)) {
				result = re_dto.getPlaneNO();
				break;
			}
		}
		return result;
	}
	
	// TODO getColumnNames : ���̺��� ����� �÷�����
	public String[] getColumnNames() {
		String[] str_columnNames = { "���Ź�ȣ", "ȸ����ȣ", "ȸ����", "������ȣ", "������ڵ�", "������",
				"��߳�¥/�ð�", "������¥/�ð�", "�����", "������", "�¼�" };
		return str_columnNames;
	}
	
	// TODO getPlaneNames : ������̸� ��� ��ȯ
	public String[] getPlaneNames() {
		String[] str_planeNames = { "�ƽþƳ�", "�����װ�", "������", "���̷���Ʈ" };
		return str_planeNames;
	}

	// TODO getSeatInfo : �¼� ��ǥ ��� ��ȯ
	public String[] getSeatInfo() {
		String[] str_seat = new String[30];
		String[] columns = { "A", "B", "C", "D", "E" };
		int count = 0;

		for (int r = 1; r <= str_seat.length / columns.length; r++) {
			for (int c = 0; c < columns.length; c++) {
				str_seat[count] = r + "-" + columns[c];
				count++;
			}
		}
		return str_seat;
	}
	
	// TODO getDateAndTime : ��¥/�ð� ���ڿ��� DTO ���·� ��ȯ
	public Reservations_DTO getDateAndTime(String startDateTime, String arrivalDateTime) {
		Reservations_DTO dto = new Reservations_DTO();
		String str_Div = " / ";
		String str_Date = startDateTime.substring(0, startDateTime.indexOf(str_Div));
		String str_Time = startDateTime.substring(startDateTime.indexOf(str_Div) + str_Div.length(), startDateTime.length());

		dto.setStartDate(Date.valueOf(str_Date));
		dto.setStartTime(str_Time);

		str_Date = arrivalDateTime.substring(0, arrivalDateTime.indexOf(str_Div));
		str_Time = arrivalDateTime.substring(arrivalDateTime.indexOf(str_Div) + str_Div.length(), startDateTime.length());

		dto.setArrivalDate(Date.valueOf(str_Date));
		dto.setArrivalTime(str_Time);

		return dto;
	}
	
	// TODO getDTOto2DObject : DTO�� 2���� �迭 ���·�
	public Object[][] getDTOto2DObject(ArrayList<Reservations_DTO> arr_dto) {
		int columnSize = getColumnNames().length;
		Object[][] arr_obj = new Object[arr_dto.size()][columnSize];

		for (int i = 0; i < arr_dto.size(); i++) {
			Reservations_DTO dto = arr_dto.get(i);

			arr_obj[i][0] = dto.getListNO();
			arr_obj[i][1] = dto.getMemberNO();
			arr_obj[i][2] = dto.getName();
			arr_obj[i][3] = dto.getPlaneNO();
			arr_obj[i][4] = dto.getPlaneCode();
			arr_obj[i][5] = dto.getPlaneName();
			arr_obj[i][6] = dto.getStartDate() + " / " + dto.getStartTime();
			arr_obj[i][7] = dto.getArrivalDate() + " / " + dto.getArrivalTime();
			arr_obj[i][8] = dto.getStartLoc();
			arr_obj[i][9] = dto.getArrivalLoc();
			arr_obj[i][10] = dto.getSeat();
		}
		return arr_obj;
	}

	// TODO getColumnIndex : ���̺��� �÷������� �÷� �ε����� ��ȯ
	public int getColumnIndex(String column) {
		ArrayList<String> arr_str = new ArrayList<>();
		for (String str : getColumnNames()) {
			arr_str.add(str);
		}
		return arr_str.indexOf(column);
	}
	
	// TODO getTableSelectedCell : �÷������� ���̺��� ���õ� ���� ���ڿ��� ��ȯ
	public String getTableSelectedCell(JTable table, String columnName) {
		return String.valueOf(table.getValueAt(table.getSelectedRow(), getColumnIndex(columnName)));
	}
	
	// TODO setColumnSize : ���̺��� �÷� ������ ���� �� ���� ����
	public void setColumnSize(JTable table, String column, int width, boolean isResize) {
		table.getColumnModel().getColumn(getColumnIndex(column)).setResizable(isResize);
		if (isResize) {
			table.getColumnModel().getColumn(getColumnIndex(column)).setPreferredWidth(width);			
		} else {
			table.getColumnModel().getColumn(getColumnIndex(column)).setWidth(width);
			table.getColumnModel().getColumn(getColumnIndex(column)).setMinWidth(width);
			table.getColumnModel().getColumn(getColumnIndex(column)).setMaxWidth(width);
		}
	}

	// TODO setTableCellCenter : ���̺��� �� ���� ��� �����ϱ�
	public void setTableCellCenter(JTable table) {
		DefaultTableCellRenderer dtcr = new DefaultTableCellRenderer();
		dtcr.setHorizontalAlignment(SwingConstants.CENTER);
		TableColumnModel tcm = table.getColumnModel();

		for (int i = 0; i < tcm.getColumnCount(); i++) {
			tcm.getColumn(i).setCellRenderer(dtcr);
		}
	}

	// TODO setTableForm : ���̺��� �� ���� �ʱ�ȭ
	public void setTableForm(JTable table, String account) {
		if (account.equals(Reservations.ACC_USER)) {
			setColumnSize(table, "ȸ����", 0, false);
		}
		
		setColumnSize(table, "���Ź�ȣ", 0, false);
		setColumnSize(table, "ȸ����ȣ", 0, false);
		setColumnSize(table, "ȸ����", 100, false);
		setColumnSize(table, "������ȣ", 0, false);
		setColumnSize(table, "������ڵ�", 80, false);
		setColumnSize(table, "�����", 80, false);
		setColumnSize(table, "������", 80, false);
		setColumnSize(table, "������", 80, false);
		setColumnSize(table, "�¼�", 40, false);

		setTableCellCenter(table);
	}
	
	// TODO showSearchResult : �˻������ ���̺��� ǥ��
	public void showSearchResult(ArrayList<Reservations_DTO> arr_dto, JTable table, String account) {
		Object[][] obj = getDTOto2DObject(arr_dto);

		@SuppressWarnings("serial")
		DefaultTableModel tableModel = new DefaultTableModel() {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false; // �� ���� �Ұ���
			}
		};
		tableModel.setDataVector(obj, getColumnNames());
		table.setModel(tableModel);
		setTableForm(table, account);
	}
	
}
