package east_view;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import db.DBConnection;
import east_reservation.Reservations;
import etc.MyFunctions;

@SuppressWarnings("serial")
public class UserView extends JFrame implements ActionListener {

	JMenuBar menubar;
	JMenu menu1, menu2, menu3;
	JMenuItem menu_member, menu_buy, menu_reservation, menu_logOut, menu_close, menu_cancelRecord, menu_signOut;
	JPanel pbtn, p_view;
	JButton btn_member, btn_buy, btn_reservation, btn_logOut, btn_close, btn_cancelRecord;
	JPanel p01, p02, p03, p04, p05, p06, p07;
	JPanel card_member, card_buy, card_reservation, card_cancelRecord;
	static JButton btn_closeNoAction, btn_signOut;
	ImageIcon icon;
	Connection con;
	PreparedStatement pstmt = null;
	ResultSet rs;
	CardLayout card = new CardLayout();

	Member_DTO dto_UserInfo;

	public UserView(Member_DTO dto_UserInfo) {
		super();
		this.dto_UserInfo = dto_UserInfo;
		setTitle("�װ��� ���� �ý��� - ���� : " + dto_UserInfo.getName());
		setLayout(new BorderLayout());

		con = DBConnection.getConnection();

		menu1 = new JMenu("�޴�");
		menu2 = new JMenu("����");
		menu3 = new JMenu("ȸ��");

		menubar = new JMenuBar();
		menu_member = new JMenuItem("��������");
		menu_buy = new JMenuItem("����");
		menu_reservation = new JMenuItem("���� ��Ȳ");
		menu_logOut = new JMenuItem("�α׾ƿ�");
		menu_close = new JMenuItem("����");
		menu_cancelRecord = new JMenuItem("����̷�");
		menu_signOut = new JMenuItem("ȸ��Ż��");

		menu1.add(menu_logOut);
		menu1.addSeparator();
		menu1.add(menu_close);
		menu2.add(menu_reservation);
		menu2.add(menu_buy);
		menu2.addSeparator();
		menu2.add(menu_cancelRecord);
		menu3.add(menu_member);
		menu3.addSeparator();
		menu3.add(menu_signOut);
		
		menubar.add(menu1);
		menubar.add(menu2);
		menubar.add(menu3);
		
		menu_member.addActionListener(this);
		menu_buy.addActionListener(this);
		menu_reservation.addActionListener(this);
		menu_logOut.addActionListener(this);
		menu_close.addActionListener(this);
		menu_cancelRecord.addActionListener(this);
		menu_signOut.addActionListener(this);

		pbtn = new JPanel(new GridLayout(12, 1));
		btn_member = new JButton("��������");
		btn_buy = new JButton("����");
		btn_reservation = new JButton("���� ��Ȳ");
		btn_logOut = new JButton("�α׾ƿ�");
		btn_close = new JButton("����");
		btn_cancelRecord = new JButton("���� ��� �̷�");
		btn_closeNoAction = new JButton("Ȯ�ξ��� �α׾ƿ�");
		btn_signOut = new JButton("ȸ��Ż��");
		
		btn_member.addActionListener(this);
		btn_buy.addActionListener(this);
		btn_reservation.addActionListener(this);
		btn_logOut.addActionListener(this);
		btn_close.addActionListener(this);
		btn_cancelRecord.addActionListener(this);
		btn_closeNoAction.addActionListener(this);
		btn_signOut.addActionListener(this);
		
		p01 = new JPanel();
		p02 = new JPanel();
		p03 = new JPanel();
		p04 = new JPanel();
		p05 = new JPanel();
		p06 = new JPanel();
		p07 = new JPanel();
		
		pbtn.add(btn_reservation);
		pbtn.add(p01);
		pbtn.add(btn_buy);
		pbtn.add(btn_cancelRecord);
		pbtn.add(p03);
		pbtn.add(p04);
		pbtn.add(btn_member);
		pbtn.add(p05);
		pbtn.add(p06);
		pbtn.add(p07);
		pbtn.add(btn_logOut);
		pbtn.add(btn_close);

		p_view = new JPanel(card);
		card_member = new JPanel();
		card_buy = new JPanel();
		card_reservation = new Reservations(this, Reservations.MODE_RESERVATION, Reservations.ACC_USER, dto_UserInfo);
		card_cancelRecord = new Reservations(this, Reservations.MODE_CANCEL, Reservations.ACC_USER, dto_UserInfo);
		
		// System.out.println("card ����");
		p_view.add(new User_panel_member(dto_UserInfo), "member");
		// System.out.println("card ��");
		p_view.add(card_buy, "buy");
		p_view.add(card_cancelRecord, "cancelRecord");
		p_view.add(card_reservation, "reservation");
		
		card_member.setBackground(Color.green);
		card_buy.setBackground(Color.black);
		card_reservation.setBackground(Color.white);
		card_cancelRecord.setBackground(Color.blue);
		card.show(p_view, "reservation");

		setJMenuBar(menubar);
		add(pbtn, "West");
		add(p_view, "Center");
		
		// setMinimumSize(new Dimension(450, 500));//�ּ� ũ�� ����
		setSize(700, 500);
		setLocation(MyFunctions.getCenterLocation(this));
		setResizable(true);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				close();
			}
		});

	}

	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if (obj == btn_member || obj == menu_member) {
			member();
		} // �α��� ���� �׼�
		if (obj == btn_buy || obj == menu_buy) {
			plane();
		} // ��й�ȣ ã�� �׼�
		if (obj == btn_reservation || obj == menu_reservation) {
			reservation();
		} // ȸ������ �׼�
		if (obj == btn_logOut || obj == menu_logOut) {
			logOut();
		}
		if (obj == btn_close || obj == menu_close) {
			close();
		}
		if (obj == btn_closeNoAction) {
			noActionClose();
		}
		if (obj == btn_signOut || obj == menu_signOut) {
			signOut();
		}
		if (obj == btn_cancelRecord || obj == menu_cancelRecord) {
			cancel();
		}
	}

	private void member() {
		card.show(p_view, "member");
		setSize(700, 500);
	} // ȸ������

	private void plane() {
		card.show(p_view, "buy");
		setSize(700, 500);
	}

	private void reservation() {
		card.show(p_view, "reservation");
		setSize(700, 500);
	}

	private void logOut() {
		int ans = JOptionPane.showConfirmDialog(null, "�α׾ƿ� �Ͻðڽ��ϱ�?", "�α׾ƿ�", JOptionPane.YES_NO_OPTION);
		if (ans == JOptionPane.YES_OPTION) {
			new Login();
			dispose();
		} else {
			return;
		}

	}

	private void close() {
		int ans = JOptionPane.showConfirmDialog(null, "���� �Ͻðڽ��ϱ�?", "����", JOptionPane.YES_NO_OPTION);
		if (ans == JOptionPane.YES_OPTION) {
			DBConnection.close();
			System.exit(0);
		}
	}

	private void cancel() {
		card.show(p_view, "cancelRecord");
		setSize(700, 500);
	}

	private void noActionClose() {
		new Login();
		dispose();
	}

	private void signOut() {
		String sql = "delete from tb_member where id = ?";
		int ans = JOptionPane.showConfirmDialog(null, "���� Ż�� �Ͻðڽ��ϱ�?", "ȸ��Ż��", JOptionPane.YES_NO_OPTION,
				JOptionPane.QUESTION_MESSAGE);
		if (ans == JOptionPane.YES_OPTION) {
			try {
				con = DBConnection.getConnection();
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, dto_UserInfo.getId());
				pstmt.executeUpdate();
				System.out.println("ȸ�� Ż�� : " + dto_UserInfo.getId() + "(" + dto_UserInfo.getName() + ")");

			} catch (Exception e) {
				JOptionPane.showMessageDialog(this, "try����5");
			}
			noActionClose();
		}

	}
}
