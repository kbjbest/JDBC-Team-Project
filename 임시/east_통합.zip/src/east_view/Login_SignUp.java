package east_view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import db.DBConnection;
import etc.MyFunctions;

@SuppressWarnings("serial")
public class Login_SignUp extends JDialog implements ActionListener, KeyListener {

	private JPanel pan_Info, p2, p3, p_phone, p01, p02, p03, p04, p05, p06;
	private JTextField east_id, east_name, east_addr, east_email, east_phone1, east_phone2, east_phone3;
	private JPasswordField pf_pw, pf_pwc;
	private JButton insert, reset, cancel;
	private JLabel lb_id, lb_pw, lb_pwc, lb_name, lb_addr, lb_email, lb_phone;
	Connection con;
	PreparedStatement pstmt = null;
	ResultSet rs;

	public Login_SignUp(JFrame frame) {// JFrame frame
		super(frame, true); // true�� �ڽ� �� ������ ������ �θ����� ������ ����
		setTitle("ȸ������");

		pan_Info = new JPanel(new BorderLayout());
		p2 = new JPanel(new GridLayout(7, 1, 5, 5));
		p3 = new JPanel(new FlowLayout());
		p01 = new JPanel(new GridLayout(2, 1, 3, 3));
		p02 = new JPanel(new GridLayout(2, 1, 3, 3));
		p03 = new JPanel(new GridLayout(2, 1, 3, 3));
		p04 = new JPanel(new GridLayout(2, 1, 3, 3));
		p05 = new JPanel(new GridLayout(2, 1, 3, 3));
		p06 = new JPanel(new GridLayout(2, 1, 3, 3));
		p_phone = new JPanel();
		
		east_id = new JTextField(5);
		east_name = new JTextField(10);
		east_addr = new JTextField(10);
		east_email = new JTextField(10);
		east_phone1 = new JTextField(3);
		east_phone2 = new JTextField(4);
		east_phone3 = new JTextField(4);
		
		insert = new JButton("����");
		insert.addActionListener(this);
		reset = new JButton("�ٽ� �ۼ�");
		reset.addActionListener(this);
		cancel = new JButton("���");
		cancel.addActionListener(this);
		
		pf_pw = new JPasswordField();
		pf_pwc = new JPasswordField();
		
		lb_id = new JLabel("���̵�");
		lb_pw = new JLabel("��й�ȣ");
		lb_pwc = new JLabel("��й�ȣ Ȯ��");
		lb_name = new JLabel("�̸�");
		lb_addr = new JLabel("�ּ�");
		lb_email = new JLabel("�̸���");
		lb_phone = new JLabel("�ڵ��� ��ȣ");
		p01.add(lb_id);
		p01.add(east_id);
		p02.add(lb_pw);
		p02.add(pf_pw);
		p03.add(lb_pwc);
		p03.add(pf_pwc);
		p04.add(lb_name);
		p04.add(east_name);
		p05.add(lb_addr);
		p05.add(east_addr);
		p06.add(lb_email);
		p06.add(east_email);
		// p07.add(lb_phone);p07.add(east_phone1);p07.add(east_phone2);p07.add(east_phone3);
		p2.add(p01);
		p2.add(p02);
		p2.add(p03);
		p2.add(p04);
		p2.add(p05);
		p2.add(p06);// p2.add(p07);
		p_phone.add(lb_phone);
		p_phone.add(east_phone1);
		east_phone1.addKeyListener(this);
		p_phone.add(east_phone2);
		east_phone2.addKeyListener(this);
		p_phone.add(east_phone3);
		east_phone3.addKeyListener(this);
		p2.add(p_phone);
		p3.add(insert);
		p3.add(reset);
		p3.add(cancel);
		pan_Info.add(p2, "Center");
		pan_Info.add(p3, "South");

		add(pan_Info);

		setSize(300, 500);
		setLocation(MyFunctions.getCenterLocation(this));
		setVisible(true);
		setResizable(true);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.out.println("2");
				dispose(); // con.close();
			}
		});

	}

	// public static void main(String[] args) {new Login_SignUp(); }
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if (obj.equals(insert)) {
			insert();
		}
		if (obj.equals(reset)) {
			reset();
		}
		if (obj.equals(cancel)) {
			cancel();
		}

	}

	public void insert() {
		String sql = "insert into tb_member values(member_seq.nextval,?,?,?,?,?,?) ";
		String phone = east_phone1.getText() + "-" + east_phone2.getText() + "-" + east_phone3.getText();

		try {
			con = DBConnection.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, east_id.getText());
			pstmt.setString(2, String.valueOf(pf_pw.getPassword()));
			pstmt.setString(3, east_name.getText());
			pstmt.setString(4, east_addr.getText());
			pstmt.setString(5, east_email.getText());
			pstmt.setString(6, phone);

			int a = pstmt.executeUpdate();
			if (a > 0) {
				JOptionPane.showMessageDialog(this, "���� ����");
			} else {
				JOptionPane.showMessageDialog(this, "���� ����");
				return;
			}

			// east_id,east_name,east_addr,east_email,east_phone1,east_phone2,east_phone3
			// pf_pw, pf_pwc;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "try����");
		}
	}

	public void reset() {

		east_id.setText("");
		east_name.setText("");
		east_addr.setText("");
		east_email.setText("");
		east_phone1.setText("");
		east_phone2.setText("");
		east_phone3.setText("");
		pf_pw.setText("");
		pf_pwc.setText("");
		east_id.requestFocus();

	}

	public void cancel() {
		dispose();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		JTextField jtf = (JTextField) e.getSource();
		if (east_phone1.getText().length() == 2) {
			east_phone2.requestFocus();
		}
		if (east_phone2.getText().length() == 3) {
			east_phone3.requestFocus();
		}
		if (jtf == east_phone1) {
			if (!(e.getKeyChar() >= '0' && e.getKeyChar() <= '9') || jtf.getText().length() >= 3) {
				e.consume();
			}

		}

		if (jtf == east_phone2) {
			if (!(e.getKeyChar() >= '0' && e.getKeyChar() <= '9') || jtf.getText().length() >= 4) {
				e.consume();
			}

		}
		if (jtf == east_phone3) {
			if (!(e.getKeyChar() >= '0' && e.getKeyChar() <= '9') || jtf.getText().length() >= 4) {
				e.consume();
			}

		}
	}

}
