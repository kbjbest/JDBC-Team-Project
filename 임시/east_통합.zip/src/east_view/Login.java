package east_view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.font.TextAttribute;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.plaf.FontUIResource;

import db.DBConnection;
import etc.MyFunctions;

@SuppressWarnings("serial")
public class Login extends JFrame implements ActionListener, MouseListener, FocusListener {
	
	JPanel pan_Background, pan_LoginView, pan_Team;
	JTextField txt_id;
	JPasswordField txt_pw;
	JButton btn_Login;
	JLabel lb_Title, lb_pw, lb_Lost, lb_Join, lb_TeamName;
	
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	
	int miss = 0;
	
	Font font_lb_original;
	Member_DTO dto_UserInfo;

	public Login() {
		super();
		setTitle("�װ��� ���� �ý��� - �α���");

		pan_Background = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				// TODO Auto-generated method stub
				g.drawImage(new ImageIcon( getClass().getClassLoader().getResource("east_index.jpg") ).getImage(), 0, 0, null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		
		pan_LoginView = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				// TODO Auto-generated method stub
				g.drawImage(new ImageIcon( getClass().getClassLoader().getResource("login.png") ).getImage(), 0, 0, null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		pan_LoginView.setPreferredSize(new Dimension(257, 213));
		pan_LoginView.setBackground(new Color(0, 0, 0, 0)); // �Է���ü ȭ��
		
		lb_Title = new JLabel("Ticket reservation system");
		lb_Title.setFont(new Font("Segoe UI", Font.BOLD + Font.ITALIC, 30));
		lb_Title.setForeground(Color.WHITE);
		
		txt_id = new JTextField("���̵�");
		txt_id.setForeground(Color.GRAY);
		txt_id.setPreferredSize(new Dimension(200, 30));
		txt_id.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createEtchedBorder(EtchedBorder.RAISED, Color.DARK_GRAY, Color.GRAY),
				BorderFactory.createEmptyBorder(5, 5, 5, 5)));
		
		txt_pw = new JPasswordField("��й�ȣ");
		txt_pw.setForeground(Color.GRAY);
		txt_pw.setPreferredSize(new Dimension(200, 30));
		txt_pw.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createEtchedBorder(EtchedBorder.RAISED, Color.DARK_GRAY, Color.GRAY),
				BorderFactory.createEmptyBorder(5, 5, 5, 5)));
		txt_pw.setEchoChar((char) 0);
		
		btn_Login = new JButton("�α���");
		btn_Login.setFont(new Font("���� ����", Font.BOLD, 15));
		btn_Login.setPreferredSize(new Dimension(190, 30));
		
		lb_Lost = new JLabel("[ ��й�ȣ? ]");
		lb_Lost.setForeground(Color.WHITE);
		lb_Join = new JLabel("[ ȸ������ ]");
		lb_Join.setForeground(Color.WHITE);

		pan_Team = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		pan_Team.setBackground(new Color(0, 0, 0, 0));
		pan_Team.setPreferredSize(new Dimension(680, 30));
		lb_TeamName = new JLabel("Project by EAST");
		lb_TeamName.setFont(new Font("Segoe UI", Font.BOLD, 12));
		lb_TeamName.setForeground(new Color(100, 100, 100));
		pan_Team.add(lb_TeamName);
		
		// �α��� ��
		pan_LoginView.add(MyFunctions.spacePanel(200, 20, null));
		pan_LoginView.add(txt_id);
		pan_LoginView.add(txt_pw);
		pan_LoginView.add(MyFunctions.spacePanel(200, 5, null));
		pan_LoginView.add(btn_Login);
		pan_LoginView.add(MyFunctions.spacePanel(200, 5, null));
		pan_LoginView.add(MyFunctions.spacePanel(200, 1, new Color(200, 200, 200)));
		pan_LoginView.add(MyFunctions.spacePanel(200, 5, null));
		pan_LoginView.add(lb_Lost);
		pan_LoginView.add(MyFunctions.spacePanel(20, 5, null));
		pan_LoginView.add(lb_Join);

		// ���
		pan_Background.add(MyFunctions.spacePanel(700, 80, null));
		pan_Background.add(lb_Title);
		pan_Background.add(MyFunctions.spacePanel(700, 20, null));
		pan_Background.add(pan_LoginView);
		pan_Background.add(pan_Team);
		add(pan_Background);

		setSize(700, 437);
		setLocation(MyFunctions.getCenterLocation(this));
		setResizable(false);
		setVisible(true);

		btn_Login.requestFocus(); // ������ ��ư���� �̵�

		txt_id.addFocusListener(this);
		txt_pw.addFocusListener(this);
		btn_Login.addActionListener(this);
		lb_Lost.addMouseListener(this);
		lb_Join.addMouseListener(this);
		
		txt_pw.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					btn_Login.doClick();
				}
			}
		});

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				DBConnection.close();
				System.exit(0);
			}
		});

	}

	public static void main(String[] args) {
		MyFunctions.setUIFont(new FontUIResource(new Font("���� ����", Font.BOLD, 13)));
		new Login();
	}

	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if (obj == btn_Login) {
			login();
		} // �α��� ���� �׼�

	}

	public void login() {

		if (txt_id.getText().equals("���̵�")) {
			JOptionPane.showMessageDialog(this, "���̵� �Է����ּ���.", "���̵� �Է�", JOptionPane.ERROR_MESSAGE);
			txt_id.requestFocus();
			return;
		}
		if (String.valueOf(txt_pw.getPassword()).equals("��й�ȣ")) {
			JOptionPane.showMessageDialog(this, "��й�ȣ�� �Է����ּ���.", "��й�ȣ �Է�", JOptionPane.ERROR_MESSAGE);
			txt_pw.requestFocus();
			return;
		}
		
		String sql = "select memberNO, ID, PW, name, address, email, phone from tb_member where id = ? ";
		try {
			con = DBConnection.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, txt_id.getText());
			rs = pstmt.executeQuery();
			
			rs.next();
			dto_UserInfo = new Member_DTO();
			dto_UserInfo.setMemberNO(rs.getInt("memberNO"));
			dto_UserInfo.setId(rs.getString("id"));
			dto_UserInfo.setPw(rs.getString("pw"));
			dto_UserInfo.setName(rs.getString("name"));
			dto_UserInfo.setAddress(rs.getString("address"));
			dto_UserInfo.setEmail(rs.getString("email"));
			dto_UserInfo.setPhone(rs.getString("phone"));
			
			if (txt_id.getText().equals(dto_UserInfo.getId()) && String.valueOf(txt_pw.getPassword()).equals(dto_UserInfo.getPw())) {

				if (dto_UserInfo.getId().equals("admin")) {
					JOptionPane.showMessageDialog(this, "�����ڷ� �α��� �ϼ̽��ϴ�."); // ������ â
					new AdminView(dto_UserInfo);
					dispose();
				} else {
					JOptionPane.showMessageDialog(this, dto_UserInfo.getName() + "��, ȯ���մϴ�!"); // ����ȸ�� â
					new UserView(dto_UserInfo);
					dispose();
				}
				
			} else {
				miss++;
				JOptionPane.showMessageDialog(this, "��й�ȣ " + miss + "�� Ʋ��", "��й�ȣ ���", JOptionPane.WARNING_MESSAGE);
				if (miss > 2) {
					JOptionPane.showMessageDialog(this, "�ý����� �����մϴ�.");
					DBConnection.close();
					System.exit(0);
				}
			}
		} catch (Exception e) {
			//e.printStackTrace();
			JOptionPane.showMessageDialog(this, "�������� �ʴ� ȸ���Դϴ�.");
		}

	}

	private void signUp() {
		new Login_SignUp(this);
	}

	private void lostPassword() {
		new Login_LostPW(this);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		JLabel label = (JLabel) e.getSource();
		if (lb_Lost.getText().equals(label.getText())) {
			lostPassword();
		} else if (lb_Join.getText().equals(label.getText())) {
			signUp();
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		font_lb_original = e.getComponent().getFont();
		Map attributes = font_lb_original.getAttributes();
		attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
		e.getComponent().setFont(font_lb_original.deriveFont(attributes));
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		e.getComponent().setFont(font_lb_original);
	}

	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {}

	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		
		if (e.getSource() == txt_id) {
			if (txt_id.getText().equals("���̵�")) {
				txt_id.setText("");
				txt_id.setForeground(Color.BLACK);
			}
		}
		if (e.getSource() == txt_pw) {
			if (String.valueOf(txt_pw.getPassword()).equals("��й�ȣ")) {
				txt_pw.setText("");
				txt_pw.setEchoChar('*');
				txt_pw.setForeground(Color.BLACK);
			}
		}
	}

	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == txt_id) {
			if (txt_id.getText().equals("")) {
				txt_id.setText("���̵�");
				txt_id.setForeground(Color.GRAY);
			}
		}
		if (e.getSource() == txt_pw) {
			if (String.valueOf(txt_pw.getPassword()).equals("")) {
				txt_pw.setText("��й�ȣ");
				txt_pw.setEchoChar((char) 0);
				txt_pw.setForeground(Color.GRAY);
			}
		}
	}
	
}
