package east_aviationinfo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import db.DBConnection;
import east_reservation.Reservations_DAO;
import etc.CalendarComboBox;

@SuppressWarnings("serial")
public class AviationView extends JPanel implements ActionListener {
	public static final int ALL = 1, SEARCH = 2;
	CalendarComboBox ccb = new CalendarComboBox();
	static TB_AviationInfoDAO dao = new TB_AviationInfoDAO();
	static Object[] columnNames = { "������ȣ", "������ڵ�", "������", "��߽ð�", "�����ð�", "�����", "������" };
	static Object rowData[][];
	static JTable table;
	static DefaultTableModel model;
	JScrollPane jsp;
	JPanel panNorth, panSouth, panCenter, p1, p2;
	JTextField tfSearch;
	JButton btSearch, btInsert, btUpdate, btDelete, btReservation;
	JLabel lbPlaneDate, lbSeat, lbEmpty1, lbEmpty2;
	Statement stmt = null;
	PreparedStatement pstmtTotalScroll, pstmtSearchScroll, pstmtTotal, pstmtSearch;
	PreparedStatement pstmtInsert, pstmtDelete;
	ResultSet rs = null;
	static public int iPlaneNo;
	static public String strPlaneCode, strPlaneName, strStartTime, strArrivalTime, strStartLoc, strArrivalLoc;
	int selectedRow;
	private String sqlDelete = "delete from tb_aviationinfo where planeno = ?";
	private String sqlInsert = "insert into tb_reservations values(reservations_seq.nextval, ?, ?, ?, ?, ?, 'n')";
	private String sqlSelect = "select memberno from tb_member where id = 'test2'";
	String strMN;
	String[] strSearch = { "��ü����", "������ڵ�", "������", "��߽ð�", "�����ð�", "�����", "������" };
	String[] strSeat = { "1-A", "1-B", "1-C", "1-D", "1-E", "2-A", "2-B", "2-C", "2-D", "2-E", "3-A", "3-B", "3-C",
			"3-D", "3-E", "4-A", "4-B", "4-C", "4-D", "4-E", "5-A", "5-B", "5-C", "5-D", "5-E", "6-A", "6-B", "6-C",
			"6-D", "6-E" };
	JComboBox<String> cbSearch = new JComboBox<String>(strSearch);
	JComboBox<String> cbSeat = new JComboBox<String>(strSeat);

	public AviationView() {
		setLayout(new BorderLayout());
		createComponent();
	}

	public void createComponent() {
		p1 = new JPanel(new GridLayout(2, 1));
		p2 = new JPanel();
		panNorth = new JPanel();
		panCenter = new JPanel();
		panSouth = new JPanel();
		panSouth.setBackground(Color.LIGHT_GRAY);

		model = new DefaultTableModel() {
			@Override
			public boolean isCellEditable(int row, int column) {
				// TODO Auto-generated method stub
				return false;
			}
		};
		table = new JTable(model);
		table.getTableHeader().setPreferredSize(new Dimension(100, 30));
		table.setRowHeight(30);
		table.getTableHeader().setReorderingAllowed(false);
		Reservations_DAO reser_dao = new Reservations_DAO();
		reser_dao.setTableCellCenter(table);
		
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ���콺�� Ŭ���� ���̺��� �� �ε��� ���
				selectedRow = table.getSelectedRow();
				if (selectedRow == -1)
					return;
				else {
					iPlaneNo = ((int) table.getValueAt(selectedRow, 0));
					strPlaneCode = ((String) table.getValueAt(selectedRow, 1));
					strPlaneName = ((String) table.getValueAt(selectedRow, 2));
					strStartTime = ((String) table.getValueAt(selectedRow, 3));
					strArrivalTime = ((String) table.getValueAt(selectedRow, 4));
					strStartLoc = ((String) table.getValueAt(selectedRow, 5));
					strArrivalLoc = ((String) table.getValueAt(selectedRow, 6));
				}
			}
		});
		jsp = new JScrollPane(table);
		
		setTableData(ALL);
		add(jsp);

		panSouth.add(cbSearch);
		panSouth.add(tfSearch = new JTextField(12));
		panSouth.add(btSearch = new JButton("�˻�"));
		panSouth.add(btInsert = new JButton("�߰�"));
		panSouth.add(btUpdate = new JButton("����"));
		panSouth.add(btDelete = new JButton("����"));
		p1.add(p2);
		p1.add(panSouth);

		Calendar date = Calendar.getInstance();
		ccb.setDate(date.get(Calendar.YEAR), date.get(Calendar.MONTH), date.get(Calendar.DATE));

		p2.add(lbPlaneDate = new JLabel("���೯¥ : "));
		p2.add(ccb);
		p2.add(lbEmpty1 = new JLabel("                 "));
		p2.add(lbSeat = new JLabel("�¼� : "));
		p2.add(cbSeat);
		p2.add(lbEmpty2 = new JLabel("                 "));
		p2.add(btReservation = new JButton("����"));
		add(p1, "South");

		// �̺�Ʈ ó��
		btSearch.addActionListener(this);
		btInsert.addActionListener(this);
		btUpdate.addActionListener(this);
		btDelete.addActionListener(this);
		btReservation.addActionListener(this);

	}

	public static void setTableData(int flag) {
		// 1]DAO���� ��� ���ڵ� ����Ÿ�� �÷������� ���

		List<TB_AviationInfoDTO> list = null;
		if (flag == ALL)
			list = dao.getRecordAll();

		// 2]�÷��ǿ� ����� ��� ���ڵ带 model�� ����
		rowData = new Object[list.size()][columnNames.length];
		for (int i = 0; i < list.size(); i++) {
			TB_AviationInfoDTO dto = list.get(i);
			rowData[i][0] = dto.getPlaneNo();
			rowData[i][1] = dto.getPlaneCode();
			rowData[i][2] = dto.getPlaneName();
			rowData[i][3] = dto.getStartTime();
			rowData[i][4] = dto.getArrivalTime();
			rowData[i][5] = dto.getStartLoc();
			rowData[i][6] = dto.getArrivalLoc();
		}
		model.setDataVector(rowData, columnNames);
		// 3]model�� table�� ����:model����� ����Ÿ�� table�� �ѷ���
		table.setModel(model);
		Reservations_DAO reser_dao = new Reservations_DAO();
		reser_dao.setTableCellCenter(table);
	}

	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == btSearch) {// �˻� ��ư Ŭ��
			// JComboBox�� ���õ� value ��������
			String fieldName = cbSearch.getSelectedItem().toString();

			if (fieldName.trim().equals("��ü����")) {// ��ü�˻�
				setTableData(ALL);
				if (model.getRowCount() > 0)
					table.setRowSelectionInterval(0, 0);
			} else {
				if (tfSearch.getText().trim().equals("")) {
					JOptionPane.showMessageDialog(null, "�˻� �ܾ �Է����ּ���!");
					tfSearch.requestFocus();
				} else {// �˻�� �Է��������
					dao.getUserSearch(model, fieldName, tfSearch.getText());
					if (model.getRowCount() > 0) {
						table.setRowSelectionInterval(0, 0);
						Reservations_DAO reser_dao = new Reservations_DAO();
						reser_dao.setTableCellCenter(table);
					}
				}
			}
		} else if (ae.getSource() == btInsert) {
			new Insert();
		} else if (ae.getSource() == btUpdate) {
			new Update();
		} else if (ae.getSource() == btDelete) {
			delete();
		} else if (ae.getSource() == btReservation) {
			reservation();
		}
	}

	/*
	 * public void search() {// ��ü ���� try { setTableData(ALL); } catch
	 * (Exception e) { System.out.println("search"); e.printStackTrace(); } }
	 */
	public void delete() { // ����
		try {
			Connection con = DBConnection.getConnection();
			if (selectedRow == -1) {
				JOptionPane.showMessageDialog(null, "������ ���ڵ带 ��������.");
				return;
			} else {
				pstmtDelete = con.prepareStatement(sqlDelete);
				String strPlaneNo = String.valueOf(AviationView.iPlaneNo);
				pstmtDelete.setString(1, strPlaneNo);
				pstmtDelete.executeUpdate();
				JOptionPane.showMessageDialog(null, "���� ����");
				setTableData(ALL);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void reservation() {// ����
		try {
			Connection con = DBConnection.getConnection();
			pstmtInsert = con.prepareStatement(sqlInsert);
			stmt = con.createStatement();
			rs = stmt.executeQuery(sqlSelect);
			if (rs.next()) {
				strMN = rs.getString("memberno");
			}
			String strMemberNo = strMN;
			String strPlaneNo = (String.valueOf(iPlaneNo));
			String strSeat = (String) cbSeat.getSelectedItem();
			String strStartDate = String.valueOf(ccb.getDate());
			String strArrivalDate = String.valueOf(ccb.getDate());

			pstmtInsert.setString(1, strMemberNo);
			pstmtInsert.setString(2, strPlaneNo);
			pstmtInsert.setString(3, strSeat);
			pstmtInsert.setString(4, strStartDate);
			pstmtInsert.setString(5, strArrivalDate);
			pstmtInsert.executeUpdate();
			JOptionPane.showMessageDialog(null, "���� ����");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
}