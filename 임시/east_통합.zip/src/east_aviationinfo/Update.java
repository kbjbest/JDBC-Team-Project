package east_aviationinfo;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import db.DBConnection;

public class Update extends JDialog implements ActionListener {
	JPanel paNorth, paSouth;
	JPanel p1, p2, p3, p4, p5, p6;
	JTextField tfPlaneCode, tfPlaneName, tfStartTime, tfArrivalTime, tfStartLoc, tfArrivalLoc;
	JButton btOK, btCancel;
	Connection con = null;
	Statement stmt = null;
	PreparedStatement pstmtUpdate;
	String sqlUpdate = "update tb_aviationinfo set planecode=?, planename=?, "
			+ "starttime=?, arrivaltime=?, startloc=?, arrivalloc=? where planeno=?";
	String adje;

	public Update() {

		// super((Frame) component, true);
		paNorth = new JPanel(new GridLayout(6, 0));
		add(paNorth, "North");

		p2 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p2.add(new JLabel("������"));
		p2.add(tfPlaneName = new JTextField(12));
		paNorth.add(p2);

		p3 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p3.add(new JLabel("��߽ð�"));
		p3.add(tfStartTime = new JTextField(12));
		paNorth.add(p3);

		p4 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p4.add(new JLabel("�����ð�"));
		p4.add(tfArrivalTime = new JTextField(12));
		paNorth.add(p4);

		p5 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p5.add(new JLabel("�����"));
		p5.add(tfStartLoc = new JTextField(12));
		paNorth.add(p5);

		p6 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p6.add(new JLabel("������"));
		p6.add(tfArrivalLoc = new JTextField(12));
		paNorth.add(p6);

		paSouth = new JPanel();
		paSouth.add(btOK = new JButton("Ȯ��"));
		paSouth.add(btCancel = new JButton("�ݱ�"));
		add(paSouth, "South");
		setBounds(600, 300, 350, 500);
		setVisible(true);

		btOK.addActionListener(this);
		btCancel.addActionListener(this);
		// dbConnect();
		tfPlaneName.setText(AviationView.strPlaneName);
		tfStartTime.setText(AviationView.strStartTime);
		tfArrivalTime.setText(AviationView.strArrivalTime);
		tfStartLoc.setText(AviationView.strStartLoc);
		tfArrivalLoc.setText(AviationView.strArrivalLoc);
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		// TODO Auto-generated method stub
		if (ae.getSource() == btOK) {
			if (tfPlaneName.getText().equals("�ƽþƳ�")) {
				adje = "A";
			} else if (tfPlaneName.getText().equals("�����װ�")) {
				adje = "D";
			} else if (tfPlaneName.getText().equals("������")) {
				adje = "J";
			} else if (tfPlaneName.getText().equals("���̷���Ʈ")) {
				adje = "E";
			}
			setTitle(ae.getActionCommand());
			update();
			dispose();
			AviationView.setTableData(1);
		} else if (ae.getSource() == btCancel) {
			dispose();
		}
	}

	public void update() {// �߰�
		try {
			Connection con = DBConnection.getConnection();
			stmt = con.createStatement();
			pstmtUpdate = con.prepareStatement(sqlUpdate);
			String strPlaneCode = adje + tfStartTime.getText().replace(":", "")+ tfArrivalTime.getText().replace(":", "");
			String strPlaneName = tfPlaneName.getText();
			String strStartTime = tfStartTime.getText();
			String strArrivalTime = tfArrivalTime.getText();
			String strStartLoc = tfStartLoc.getText();
			String strArrivalLoc = tfArrivalLoc.getText();
			String strPlaneNo = String.valueOf(AviationView.iPlaneNo);
			System.out
					.println(strPlaneCode + strPlaneName + strStartTime + strArrivalTime + strStartLoc + strArrivalLoc);
			if (strPlaneCode.length() < 1 || strPlaneName.length() < 1 || strStartTime.length() < 1
					|| strArrivalTime.length() < 1 || strStartLoc.length() < 1 || strArrivalLoc.length() < 1) {
				JOptionPane.showMessageDialog(null, "��� �׸��� �� �Է��Ͻʽÿ�.");
				return;
			} else {
				pstmtUpdate.setString(1, strPlaneCode);
				pstmtUpdate.setString(2, strPlaneName);
				pstmtUpdate.setString(3, strStartTime);
				pstmtUpdate.setString(4, strArrivalTime);
				pstmtUpdate.setString(5, strStartLoc);
				pstmtUpdate.setString(6, strArrivalLoc);
				pstmtUpdate.setString(7, strPlaneNo);
				// ystem.out.println(strPlaneCode + strPlaneName + strStartTime
				// + strArrivalTime + strStartLoc + strArrivalLoc + strPlaneNo);
				pstmtUpdate.executeUpdate();
				JOptionPane.showMessageDialog(null, "���� ����");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}