package east_aviationinfo;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import db.DBConnection;

public class Insert extends JDialog implements ActionListener {
	JPanel paNorth, paSouth;
	JPanel p1, p2, p3, p4, p5, p6;
	JTextField tfPlaneCode, tfPlaneName, tfStartTime, tfArrivalTime, tfStartLoc, tfArrivalLoc;
	JButton btOK, btCancel;
	Connection con = null;
	Statement stmt = null;
	PreparedStatement pstmtInsert;
	String sqlInsert = "insert into tb_aviationinfo values(aviationinfo_seq.nextval, ?, ?, ?, ?, ?, ?)";
	String adje;

	public Insert( /* Component component */) {
		// super((Frame) component, true);
		paNorth = new JPanel(new GridLayout(6, 0));
		add(paNorth, "North");

		p2 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p2.add(new JLabel("������"));
		p2.add(tfPlaneName = new JTextField(12));
		paNorth.add(p2);

		p3 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p3.add(new JLabel("��߽ð�"));
		p3.add(tfStartTime = new JTextField(12));
		paNorth.add(p3);

		p4 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p4.add(new JLabel("�����ð�"));
		p4.add(tfArrivalTime = new JTextField(12));
		paNorth.add(p4);

		p5 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p5.add(new JLabel("�����"));
		p5.add(tfStartLoc = new JTextField(12));
		paNorth.add(p5);

		p6 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p6.add(new JLabel("������"));
		p6.add(tfArrivalLoc = new JTextField(12));
		paNorth.add(p6);

		paSouth = new JPanel();
		paSouth.add(btOK = new JButton("Ȯ��"));
		paSouth.add(btCancel = new JButton("�ݱ�"));
		add(paSouth, "South");
		setBounds(600, 300, 350, 500);
		setVisible(true);

		btOK.addActionListener(this);
		btCancel.addActionListener(this);
		// dbConnect();
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		// TODO Auto-generated method stub
		if (ae.getSource() == btOK) {
			if (tfPlaneName.getText().equals("�ƽþƳ�")) {
				adje = "A";
			} else if (tfPlaneName.getText().equals("�����װ�")) {
				adje = "D";
			} else if (tfPlaneName.getText().equals("������")) {
				adje = "J";
			} else if (tfPlaneName.getText().equals("���̷���Ʈ")) {
				adje = "E";
			}
			insert();
			dispose();
			AviationView.setTableData(1);

		} else if (ae.getSource() == btCancel) {
			dispose();
		}
		// setText(NONE);
		// init();
	}

	public void insert() {// �߰�
		try {
			Connection con = DBConnection.getConnection();
			stmt = con.createStatement();
			pstmtInsert = con.prepareStatement(sqlInsert);
			String strPlaneCode = adje + tfStartTime.getText().replace(":", "")+ tfArrivalTime.getText().replace(":", "");
			String strPlaneName = tfPlaneName.getText();
			String strStartDate = tfStartTime.getText();
			String strArrivalDate = tfArrivalTime.getText();
			String strStartLoc = tfStartLoc.getText();
			String strArrivalLoc = tfArrivalLoc.getText();
			if (strPlaneCode.length() < 1 || strPlaneName.length() < 1 || strStartDate.length() < 1
					|| strArrivalDate.length() < 1 || strStartLoc.length() < 1 || strArrivalLoc.length() < 1) {
				JOptionPane.showMessageDialog(null, "��� �׸��� �� �Է��Ͻʽÿ�.");
				return;
			} else {
				pstmtInsert.setString(1, strPlaneCode);
				pstmtInsert.setString(2, strPlaneName);
				pstmtInsert.setString(3, strStartDate);
				pstmtInsert.setString(4, strArrivalDate);
				pstmtInsert.setString(5, strStartLoc);
				pstmtInsert.setString(6, strArrivalLoc);
				pstmtInsert.executeUpdate();
				JOptionPane.showMessageDialog(null, "�߰� ����");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}