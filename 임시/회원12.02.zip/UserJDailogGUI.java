//UserJDailogGUI.java
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class UserJDailogGUI extends JDialog implements ActionListener{
	
	JPanel pw=new JPanel(new GridLayout(8,1));
	//JPanel pc=new JPanel(new GridLayout(4,1));
	JPanel ps=new JPanel();
	
	JLabel lable_Memberno = new JLabel("MEMBERNO");
	JLabel lable_Id = new JLabel("    ID");
	JLabel lable_Pwd= new JLabel("PWD");
	JLabel lable_Name=new JLabel("�̸�");
	JLabel lable_Address=new JLabel("�ּ�");
	JLabel lable_Email=new JLabel("�̸���");
	JLabel lable_Phone = new JLabel("��ȭ��ȣ");
	

	JTextField memberno=new JTextField();
	JTextField id=new JTextField();
	JTextField pwd=new JTextField();
	JTextField name=new JTextField();
	JTextField address=new JTextField();
	JTextField email=new JTextField();
	JTextField phone=new JTextField();
	JButton confirm;
	JButton reset=new JButton("���");

   MenuJTabaleExam me;

   //JPanel membernoCkP =new JPanel(new BorderLayout());
   //JButton membernoCkBtn = new JButton("MembernoCheck");
   
   UserDefaultJTableDAO dao =new UserDefaultJTableDAO();
   

	public UserJDailogGUI(MenuJTabaleExam me, String index){
		setLayout(new BorderLayout());
		this.me=me;
		if(index.equals("����")){
			confirm=new JButton(index);
		}else{
			confirm=new JButton("����");	
			
			int row = me.jt.getSelectedRow();//���õ� ��
			memberno.setText( me.jt.getValueAt(row, 0).toString() );
			id.setText( me.jt.getValueAt(row, 1).toString() );
			pwd.setText( me.jt.getValueAt(row, 2).toString() );
			name.setText( me.jt.getValueAt(row, 3).toString() );
			address.setText( me.jt.getValueAt(row, 4).toString() );
			email.setText( me.jt.getValueAt(row, 5).toString() );
			if (phone.getText().equals("")) {
				phone.setText("");
			} else {
				phone.setText( me.jt.getValueAt(row, 6).toString() );
			}
						
		}	
		memberno.setEnabled(false);
		id.setEnabled(false);
		pw.add(lable_Memberno);
		pw.add(memberno);
		pw.add(lable_Id);
		pw.add(id);
		pw.add(lable_Pwd);
		pw.add(pwd);
		pw.add(lable_Name);
		pw.add(name);
		pw.add(lable_Address);
		pw.add(address);
		pw.add(lable_Email);
		pw.add(email);
		pw.add(lable_Phone);
		pw.add(phone);
		
	//	membernoCkP.add(memberno,"Center");
		
		
		
				
		
		ps.add(confirm); 
		ps.add(reset);
	
		add(pw,"West"); 
		//add(pc,"Center");
		add(ps,"South");
		
		setSize(600,400);
		setVisible(true);

		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		
        confirm.addActionListener(this); 
        reset.addActionListener(this);
       
		
	}
    
	/**
	 * ����/����/���� ��ɿ� ���� �κ�
	 * */
	@Override
	public void actionPerformed(ActionEvent e) {
	   String btnLabel =e.getActionCommand();//�̺�Ʈ��ü ���� Label ��������
	    
	  if(btnLabel.equals("����")){
		   
		    if( dao.userUpdate(this) > 0){
		    	messageBox(this, "�����Ϸ�Ǿ����ϴ�.");
		    	dispose();
		    	dao.userSelectAll(me.dt);
		    	if(me.dt.getRowCount() > 0 ) me.jt.setRowSelectionInterval(0, 0);
		    	
		    }else{
		    	messageBox(this, "�������� �ʾҽ��ϴ�.");
		    }
		   
		   
		   
	   }else if(btnLabel.equals("���")){
		   dispose();
		   
	   }
	   //else if(btnLabel.equals("MEMBERNOCheck")){
		   //id�ؽ�Ʈ�ڽ��� �� ������ �޼��� ��� ������ DB�����Ѵ�.
		 //  if(id.getText().trim().equals("")){
			//   messageBox(this,"ȸ����ȣ �� �Է����ּ���.");
			  // id.requestFocus();//��Ŀ���̵�
		   //}else{
			   
			 // if(  dao.getMembernoByCheck(id.getText()) ){ //�ߺ��ƴϴ�.(��밡��) 
				//  messageBox(this, id.getText()+"�� ��밡���մϴ�.");  
			//  }else{ //�ߺ��̴�.
				//  messageBox(this,id.getText()+"�� �ߺ��Դϴ�.");
				  
				  //id.setText("");
				  //id.requestFocus();
			  //}
			   
		   //}
		   
	   }
	   
		
	//}
	
	/**
	 * �޽����ڽ� ����ִ� �޼ҵ� �ۼ�
	 * */
	
	
	public static void messageBox(Object obj , String message){
		JOptionPane.showMessageDialog( (Component)obj , message);
	}

}//Ŭ������