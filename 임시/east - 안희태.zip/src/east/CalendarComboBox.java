package east;

import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Date;
import java.util.Calendar;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class CalendarComboBox extends JPanel implements ItemListener {

	private JComboBox<Integer> cb_Year, cb_Month, cb_Day;
	private int year, month, day;
	
	private Calendar date;
	
	public CalendarComboBox() {
		// TODO CalendarComboBox ������
		date = Calendar.getInstance();
		
		cb_Year = new JComboBox<>();
		cb_Month = new JComboBox<>();
		cb_Day = new JComboBox<>();
		
		cb_Year.setSize(50,25);
		cb_Month.setSize(50,25);
		cb_Day.setSize(50,25);
		
		for (int y = 1970; y < 2100; y++) {
			cb_Year.addItem(y);
		}
		
		for (int m = 1; m <= 12; m++) {
			cb_Month.addItem(m);
		}
		
		for (int d = 1; d <= date.getActualMaximum(Calendar.DATE); d++) {
			cb_Day.addItem(d);
		}
		
		add(cb_Year);
		add(new JLabel("  "));
		add(cb_Month);
		add(new JLabel("  "));
		add(cb_Day);
		
		cb_Year.addItemListener(this);
		cb_Month.addItemListener(this);
		cb_Day.addItemListener(this);
		
		setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
	}
	
	@Override
	public void setEnabled(boolean enabled) {
		// TODO �ش� Panel�� Ȱ�� ���ο� ���� ���� ������Ʈ�� Ȱ�� ���θ� �����Ѵ�.
		cb_Year.setEnabled(enabled);
		cb_Month.setEnabled(enabled);
		cb_Day.setEnabled(enabled);
	}
	
	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO �޺��ڽ��� ���� ����� ���
		
		if (e.getSource() == cb_Year) {
			year = (int)cb_Year.getSelectedItem();
			date.set(Calendar.YEAR, year);
			
		} else if (e.getSource() == cb_Month) {
			month = (int)cb_Month.getSelectedItem();
			date.set(Calendar.MONTH, month - 1);
			
		} else if (e.getSource() == cb_Day) {
			if (cb_Day.getSelectedItem() != null) {
				day = (int)cb_Day.getSelectedItem();
				date.set(Calendar.DATE, day);
			}
		}
		
		if (e.getSource() != cb_Day) {
			
			cb_Day.removeAllItems();
			for (int d = 1; d <= date.getActualMaximum(Calendar.DATE); d++) {
				cb_Day.addItem(d);
			}
		}
	}
	
	public void setDate(int year, int month, int day) {
		this.year = year;
		this.month = month + 1;
		this.day = day;
		cb_Year.setSelectedItem(year);
		cb_Month.setSelectedItem(month + 1);
		cb_Day.setSelectedItem(day);
	}
	
	public Date getDate() {
		Date d = new Date(date.getTimeInMillis());
		return d;
	}
	
	public int getYear() {
		return year;
	}

	public int getMonth() {
		return month;
	}
	
	public int getDay() {
		return day;
	}
	
}
