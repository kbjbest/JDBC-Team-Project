package east_member;
 

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
 
@SuppressWarnings("serial")
public class UserJDailogGUI extends JDialog implements ActionListener, KeyListener{
	JPanel pw=new JPanel(new GridLayout(8,1));
	JPanel pc=new JPanel(new GridLayout(8,1));
	JPanel pan_phone = new JPanel();
	@Override
	public void setBounds(int x, int y, int width, int height) {
		// TODO Auto-generated method stub
		super.setBounds(600,300 ,300,350);
	}
	JPanel ps=new JPanel();
	JLabel lable_Memberno = new JLabel("ȸ����ȣ");
	JLabel lable_Id = new JLabel("���̵�");
	JLabel lable_Pwd= new JLabel("��й�ȣ");
	JLabel lable_Name=new JLabel("�̸�");
	JLabel lable_Address=new JLabel("�ּ�");
	JLabel lable_Email=new JLabel("�̸���");
	JLabel lable_Phone = new JLabel("��ȭ��ȣ");
	
	JTextField memberno=new JTextField(10);
	JTextField id=new JTextField(10);
	JTextField pwd=new JTextField(10);
	JTextField name=new JTextField(10);
	JTextField address=new JTextField(10);
	JTextField email=new JTextField(10);
	JTextField phone1 = new JTextField(3);
	JTextField phone2 = new JTextField(4);
	JTextField phone3 = new JTextField(4);
	JButton confirm=new JButton("����");
	JButton reset=new JButton("���");
 
	MenuJTabaleExam me;
 
	
	UserDefaultJTableDAO dao =new UserDefaultJTableDAO();
	
	public UserJDailogGUI(MenuJTabaleExam me, String index){
	setLayout(new BorderLayout());
	
	this.me=me;
	int row = me.jt.getSelectedRow();
	memberno.setText( me.jt.getValueAt(row, 0).toString() );
	id.setText( me.jt.getValueAt(row, 1).toString() );
	pwd.setText( me.jt.getValueAt(row, 2).toString() );
	name.setText( me.jt.getValueAt(row, 3).toString() );
	address.setText( me.jt.getValueAt(row, 4).toString() );
	email.setText( me.jt.getValueAt(row, 5).toString() );
	String str_phone = "";
	if (me.jt.getValueAt(row, 6) != null) {
		str_phone = me.jt.getValueAt(row, 6).toString();		
	}
	if (!str_phone.equals("")) {
		phone1.setText(str_phone.split("-")[0]);
		phone2.setText(str_phone.split("-")[1]);
		phone3.setText(str_phone.split("-")[2]);		
	}
	
	memberno.setEnabled(false);
	memberno.setPreferredSize(new Dimension(2,20));
	id.setEnabled(false);
	pw.add(lable_Memberno);
	pc.add(memberno);
	pw.add(lable_Id);
	pc.add(id);
	pw.add(lable_Pwd);
	pc.add(pwd);
	pw.add(lable_Name);
	pc.add(name);
	pw.add(lable_Address);
	pc.add(address);
	pw.add(lable_Email);
	pc.add(email);
	pw.add(lable_Phone);
	
	pan_phone.add(phone1);
	phone1.addKeyListener(this);
	pan_phone.add(phone2);
	phone2.addKeyListener(this);
	pan_phone.add(phone3);
	phone3.addKeyListener(this);
	pc.add(pan_phone);

	
	ps.add(confirm);
	ps.add(reset);
	add(pw,"West");
	add(pc,"Center");
	add(ps,"South");
	setSize(500,500);
	setVisible(true);
	
	setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
	confirm.addActionListener(this);
	reset.addActionListener(this);

	
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String btnLabel =e.getActionCommand();
		if(btnLabel.equals("����")){
			if(phone1.getText().length()!=0 || phone2.getText().length()!=0 || phone3.getText().length()!=0){
				if (phone1.getText().length()!=3 || phone2.getText().length()!=4 || phone3.getText().length()!=4) {
					JOptionPane.showMessageDialog(this,"��ȭ��ȣ ������ �ùٸ��� �ʽ��ϴ�.");
					return;
				}
			}
			if( dao.userUpdate(this) > 0){
				messageBox(this, "������ �Ϸ� �Ǿ����ϴ�.");
				dispose();
				dao.userSelectAll(me.dt);
				if(me.dt.getRowCount() > 0 ) me.jt.setRowSelectionInterval(0, 0);
			}else{
				messageBox(this, "�������� �ʾҽ��ϴ�.");
			}
		}else if(btnLabel.equals("���")){
			dispose();
		}
	
	}
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		JTextField jtf = (JTextField) e.getSource();
		if (phone1.getText().length() == 2) {
			phone2.requestFocus();
		}
		if (phone2.getText().length() == 3) {
			phone3.requestFocus();
		}
		if (jtf == phone1) {
			if (!(e.getKeyChar() >= '0' && e.getKeyChar() <= '9') || jtf.getText().length() >= 3) {
				e.consume();
			}

		}

		if (jtf == phone2) {
			if (!(e.getKeyChar() >= '0' && e.getKeyChar() <= '9') || jtf.getText().length() >= 4) {
				e.consume();
			}

		}
		if (jtf == phone3) {
			if (!(e.getKeyChar() >= '0' && e.getKeyChar() <= '9') || jtf.getText().length() >= 4) {
				e.consume();
			}

		}
	}
 
	
	public static void messageBox(Object obj , String message){
		JOptionPane.showMessageDialog( (Component)obj , message);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
 
}