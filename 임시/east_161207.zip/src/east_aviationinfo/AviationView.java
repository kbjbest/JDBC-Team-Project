package east_aviationinfo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import db.DBConnection;
import east_reservation.Reservations_DAO;
import east_view.Member_DTO;
import etc.CalendarComboBox;

@SuppressWarnings("serial")
public class AviationView extends JPanel implements ActionListener, ItemListener {
	public static final int ALL = 1, SEARCH = 2;
	static CalendarComboBox ccb = new CalendarComboBox();
	static TB_AviationInfoDAO dao = new TB_AviationInfoDAO();
	static Object[] columnNames = { "������ȣ", "������ڵ�", "������", "��߽ð�", "�����ð�", "�����", "������" };
	static Object rowData[][];
	static JTable table;
	static DefaultTableModel model;
	JScrollPane jsp;
	JPanel panNorth, panSouth, panCenter, p1, p2;
	JTextField tfSearch;
	JButton btSearch, btInsert, btUpdate, btDelete, btReservation;
	JLabel lbPlaneDate, lbSeat, lbEmpty1, lbEmpty2;
	Statement stmt = null;
	PreparedStatement pstmtTotalScroll, pstmtSearchScroll, pstmtTotal, pstmtSearch;
	PreparedStatement pstmtInsert, pstmtDelete;
	PreparedStatement pstmt;
	ResultSet rs = null;
	static public int iPlaneNo;
	static public String strPlaneCode, strPlaneName, strStartTime, strArrivalTime, strStartLoc, strArrivalLoc,
			strStartDate;
	private String sqlDelete = "delete from tb_aviationinfo where planeno = ?";
	private String sqlInsert = "insert into tb_reservations values(reservations_seq.nextval, ?, ?, ?, ?, ?, 'n')";
	private String sqlSelect = "select memberno from tb_member where id = ";
	private String sqlSeat = "select seat from tb_reservations r, tb_aviationinfo a where a.planecode = ? and startdate = ? and r.planeno = a.planeno and cancel = 'n'";
	String strMN;
	String strSelectedSeat;
	String[] strSearch = { "��ü����", "������ڵ�", "������", "��߽ð�", "�����ð�", "�����", "������" };
	static String[] strSeat = { "1-A", "1-B", "1-C", "1-D", "1-E", "2-A", "2-B", "2-C", "2-D", "2-E", "3-A", "3-B",
			"3-C", "3-D", "3-E", "4-A", "4-B", "4-C", "4-D", "4-E", "5-A", "5-B", "5-C", "5-D", "5-E", "6-A", "6-B",
			"6-C", "6-D", "6-E" };
	JComboBox<String> cbSearch = new JComboBox<String>(strSearch);
	static JComboBox<String> cbSeat = new JComboBox<String>(strSeat);

	JFrame mainFrame;

	TB_AviationInfoDTO dto = new TB_AviationInfoDTO();

	public AviationView() {
	}

	public AviationView(JFrame mainFrame, Member_DTO dto_userInfo) {
		this.mainFrame = mainFrame;
		sqlSelect += "'" + dto_userInfo.getId() + "' ";
		setLayout(new BorderLayout());
		createComponent();
		ccb.cb_Year.addItemListener(this);
		ccb.cb_Month.addItemListener(this);
		ccb.cb_Day.addItemListener(this);
	}

	public void createComponent() {
		p1 = new JPanel(new GridLayout(2, 1));
		p2 = new JPanel();
		panNorth = new JPanel();
		panCenter = new JPanel();
		panSouth = new JPanel();
		panSouth.setBackground(Color.LIGHT_GRAY);

		model = new DefaultTableModel() {
			@Override
			public boolean isCellEditable(int row, int column) {
				// TODO Auto-generated method stub
				return false;
			}
		};
		table = new JTable(model);
		table.getTableHeader().setPreferredSize(new Dimension(100, 30));
		table.setRowHeight(30);
		table.getTableHeader().setReorderingAllowed(false);
		Reservations_DAO reser_dao = new Reservations_DAO();
		reser_dao.setTableCellCenter(table);

		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ���콺�� Ŭ���� ���̺��� �� �ε��� ���
				cbSeat.insertItemAt("1-A", 0);
				cbSeat.insertItemAt("1-B", 1);
				cbSeat.insertItemAt("1-C", 2);
				cbSeat.insertItemAt("1-D", 3);
				cbSeat.insertItemAt("1-E", 4);
				cbSeat.insertItemAt("2-A", 5);
				cbSeat.insertItemAt("2-B", 6);
				cbSeat.insertItemAt("2-C", 7);
				cbSeat.insertItemAt("2-D", 8);
				cbSeat.insertItemAt("2-E", 9);
				cbSeat.insertItemAt("3-A", 10);
				cbSeat.insertItemAt("3-B", 11);
				cbSeat.insertItemAt("3-C", 12);
				cbSeat.insertItemAt("3-D", 13);
				cbSeat.insertItemAt("3-E", 14);
				cbSeat.insertItemAt("4-A", 15);
				cbSeat.insertItemAt("4-B", 16);
				cbSeat.insertItemAt("4-C", 17);
				cbSeat.insertItemAt("4-D", 18);
				cbSeat.insertItemAt("4-E", 19);
				cbSeat.insertItemAt("5-A", 20);
				cbSeat.insertItemAt("5-B", 21);
				cbSeat.insertItemAt("5-C", 22);
				cbSeat.insertItemAt("5-D", 23);
				cbSeat.insertItemAt("5-E", 24);
				cbSeat.insertItemAt("6-A", 25);
				cbSeat.insertItemAt("6-B", 26);
				cbSeat.insertItemAt("6-C", 27);
				cbSeat.insertItemAt("6-D", 28);
				cbSeat.insertItemAt("6-E", 29);
				if (table.getSelectedRow() == -1)
					return;
				else {
					getInsertItem();
					seat();

				}

				if (e.getClickCount() == 2) {

					seat();
					btUpdate.doClick();
				}

			}
		});

		jsp = new JScrollPane(table);

		setTableData(ALL);
		add(jsp);

		panSouth.add(cbSearch);
		panSouth.add(tfSearch = new JTextField(12));
		panSouth.add(btSearch = new JButton("�˻�"));
		panSouth.add(btInsert = new JButton("�߰�"));
		panSouth.add(btUpdate = new JButton("����"));
		panSouth.add(btDelete = new JButton("����"));
		p1.add(p2);
		p1.add(panSouth);

		tfSearch.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					btSearch.doClick();
				}
			}
		});

		Calendar date = Calendar.getInstance();
		ccb.setDate(date.get(Calendar.YEAR), date.get(Calendar.MONTH), date.get(Calendar.DATE));

		p2.add(lbPlaneDate = new JLabel("���೯¥ : "));
		p2.add(ccb);
		p2.add(lbEmpty1 = new JLabel("                 "));
		p2.add(lbSeat = new JLabel("�¼� : "));
		p2.add(cbSeat);
		p2.add(lbEmpty2 = new JLabel("                 "));
		p2.add(btReservation = new JButton("����"));
		add(p1, "South");

		// �̺�Ʈ ó��
		btSearch.addActionListener(this);
		btInsert.addActionListener(this);
		btUpdate.addActionListener(this);
		btDelete.addActionListener(this);
		btReservation.addActionListener(this);

	}

	public void getInsertItem() {
		if (table.getSelectedRow() != -1) {
			dto.setPlaneNo(iPlaneNo = ((int) table.getValueAt(table.getSelectedRow(), 0)));
			dto.setPlaneCode(strPlaneCode = ((String) table.getValueAt(table.getSelectedRow(), 1)));
			dto.setPlaneName(strPlaneName = ((String) table.getValueAt(table.getSelectedRow(), 2)));
			dto.setStartTime(strStartTime = ((String) table.getValueAt(table.getSelectedRow(), 3)));
			dto.setArrivalTime(strArrivalTime = ((String) table.getValueAt(table.getSelectedRow(), 4)));
			dto.setStartLoc(strStartLoc = ((String) table.getValueAt(table.getSelectedRow(), 5)));
			dto.setArrivalLoc(strArrivalLoc = ((String) table.getValueAt(table.getSelectedRow(), 6)));
//			System.out.println(strPlaneName);
		}

	}

	public static void setTableData(int flag) {
		// 1]DAO���� ��� ���ڵ� ����Ÿ�� �÷������� ���

		List<TB_AviationInfoDTO> list = null;
		if (flag == ALL)
			list = dao.getRecordAll();

		// 2]�÷��ǿ� ����� ��� ���ڵ带 model�� ����
		rowData = new Object[list.size()][columnNames.length];
		for (int i = 0; i < list.size(); i++) {
			TB_AviationInfoDTO dto = list.get(i);
			rowData[i][0] = dto.getPlaneNo();
			rowData[i][1] = dto.getPlaneCode();
			rowData[i][2] = dto.getPlaneName();
			rowData[i][3] = dto.getStartTime();
			rowData[i][4] = dto.getArrivalTime();
			rowData[i][5] = dto.getStartLoc();
			rowData[i][6] = dto.getArrivalLoc();
		}
		model.setDataVector(rowData, columnNames);
		// 3]model�� table�� ����:model����� ����Ÿ�� table�� �ѷ���
		table.setModel(model);
		Reservations_DAO reser_dao = new Reservations_DAO();
		reser_dao.setTableCellCenter(table);
	}

	public void actionPerformed(ActionEvent ae) {
		getInsertItem();

		if (ae.getSource() == btSearch) {// �˻� ��ư Ŭ��
			// JComboBox�� ���õ� value ��������
			String fieldName = cbSearch.getSelectedItem().toString();

			if (fieldName.trim().equals("��ü����")) {// ��ü�˻�
				setTableData(ALL);
				if (model.getRowCount() > 0)
					table.setRowSelectionInterval(0, 0);
			} else {
				if (tfSearch.getText().trim().equals("")) {
					JOptionPane.showMessageDialog(null, "�˻� �ܾ �Է����ּ���!");
					tfSearch.requestFocus();
				} else {// �˻�� �Է��������
					dao.getUserSearch(model, fieldName, tfSearch.getText());
					if (model.getRowCount() > 0) {
						table.setRowSelectionInterval(0, 0);
						Reservations_DAO reser_dao = new Reservations_DAO();
						reser_dao.setTableCellCenter(table);
					}
				}
			}
		} else if (ae.getSource() == btInsert) {
			new Insert(mainFrame);
		} else if (ae.getSource() == btUpdate) {
			if (table.getSelectedRow() == -1)
				JOptionPane.showMessageDialog(null, "������ ����� �����ϼ���!");
			else
				new Update(mainFrame, dto);
		} else if (ae.getSource() == btDelete) {
			delete();
		} else if (ae.getSource() == btReservation) {
			if (table.getSelectedRow() == -1)
				JOptionPane.showMessageDialog(null, "������ ����� �����ϼ���!");
			else {
				new Reservation(mainFrame);
			}
		}
	}

	public void delete() { // ����
		try {
			Connection con = DBConnection.getConnection();
			if (table.getSelectedRow() == -1) {
				JOptionPane.showMessageDialog(null, "������ ���ڵ带 ��������.");
				return;
			} else {
				int msg = JOptionPane.showConfirmDialog(null, "������ �����Ͻðڽ��ϱ�?", "WARNING", JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.WARNING_MESSAGE);
				if (msg == JOptionPane.OK_OPTION) {
					pstmtDelete = con.prepareStatement(sqlDelete);
					String strPlaneNo = String.valueOf(table.getValueAt(table.getSelectedRow(), 0));
					pstmtDelete.setString(1, strPlaneNo);
					int result = pstmtDelete.executeUpdate();
					if (result > 0) {
						JOptionPane.showMessageDialog(null, "���� ����");
					} else {
						JOptionPane.showMessageDialog(null, "���� ����");
					}
					setTableData(ALL);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void seat() {
		try {

			Connection con = DBConnection.getConnection();
			pstmt = con.prepareStatement(sqlSeat);
			pstmt.setString(1, strPlaneCode);
			pstmt.setString(2, String.valueOf(ccb.getDate()));
			rs = pstmt.executeQuery();

			while (rs.next()) {
				strSelectedSeat = rs.getString("seat");
				cbSeat.removeItem(strSelectedSeat);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		seat();
	}

}