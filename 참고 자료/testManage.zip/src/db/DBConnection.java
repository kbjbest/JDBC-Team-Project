package db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

	private static Connection conn;
	
	/**
	 * DB ����
	 * @return DB Ŀ�ؼ�
	 */
	public static Connection getConnection() {
		if (conn == null) {
			try {
				String url = "jdbc:oracle:thin:@localhost:1521:orcl";
				String user = "lion";
				String password = "1234";
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				conn = DriverManager.getConnection(url, user, password);
				
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return conn;
	}
	
	/**
	 * DB ����
	 * @param url ������ ����Ŭ DB �ּ�
	 * @param user DB ������
	 * @param password DB ���� ��й�ȣ
	 * @return DB Ŀ�ؼ�
	 */
	public static Connection getConnection(String url, String user, String password) {
		if (conn == null) {
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				conn = DriverManager.getConnection(url, user, password);
				
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return conn;
	}
	
	/**
	 * DB ���� ����
	 */
	public static void close() {
		try {
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		conn = null;
	}
	
}
