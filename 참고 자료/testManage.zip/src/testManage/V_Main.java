package testManage;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import aht.MyFunctions;

@SuppressWarnings("serial")
public class V_Main extends JFrame implements ActionListener {

	public V_Main() {
		// TODO Auto-generated constructor stub
		super();
		
		setTitle("���� ������");
		setSize(500, 500);
		setLocation(MyFunctions.getCenterLocation(this));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
