package testManage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import db.DBConnection;

public class M_DAO_Login_SignUp {

	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	private M_DTO userInfo;
	
	public boolean checkUser(String id, String pw) {		
		boolean isUser = false;
		
		con = DBConnection.getConnection();
		
		try {
			String sql;
			
			if (pw == null) { // id�� üũ�� ��
				sql = "select USERNO from USERLIST "
						+ "where ID = ?";
				
			} else { // id�� pw ��� üũ�� ��
				sql = "select USERNO, ID, PW, BIRTHDAY, ADDRESS from USERLIST "
						+ "where ID = ? and PW = ?";
			}
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				if (pw != null) {
					userInfo = new M_DTO();
					userInfo.setId(rs.getString("ID"));
					userInfo.setPw(rs.getString("PW"));
					userInfo.setBirthday(rs.getString("BIRTHDAY"));
					userInfo.setAddress("ADDRESS");
				}
				isUser = true;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			ConnClose();
		}
		
		return isUser;
	}
	
	public M_DTO getUserInfo() {
		return userInfo;
	}
	
	public void ConnClose() {
		try {
			if (rs != null && !rs.isClosed()) {
				rs.close();
			}
			if (pstmt != null && !pstmt.isClosed()) {
				pstmt.close();
			}
			DBConnection.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
}
