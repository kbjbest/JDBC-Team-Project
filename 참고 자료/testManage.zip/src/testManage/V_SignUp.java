package testManage;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import aht.MyFunctions;

@SuppressWarnings("serial")
public class V_SignUp extends JDialog implements ActionListener {

	private M_DAO_Login_SignUp dao_SignUp;
	
	private JPanel pan_CriticlaItems, pan_SelectiveItems, pan_Bottom;
	private JTextField tf_Id;
	private JPasswordField pf_Pw, pf_Pw_Confirm;
	private JComboBox<Integer> cb_Birthday_Year, cb_Birthday_Month, cb_Birthday_Day;
	private JComboBox<String> cb_Address_1, cb_Address_2, cb_Address_3;
	private JButton btn_DuplicateCheck, btn_SignUp, btn_Cancel;
	
	public V_SignUp(Component component) {
		// TODO Auto-generated constructor stub
		super((JFrame) component, "ȸ������", true);
		Container container = getContentPane();
		container.setLayout(new FlowLayout(FlowLayout.CENTER));
		
		pan_CriticlaItems = new JPanel(new GridBagLayout());
		//pan_CriticlaItems.setPreferredSize(new Dimension(300, 130));
		
		
		
		container.add(pan_CriticlaItems);
		container.add(MyFunctions.spacePanel(300, 1, null));
		
		//btn_DuplicateCheck.addActionListener(this);
		//btn_SignUp.addActionListener(this);
		//btn_Cancel.addActionListener(this);
		
		setSize(350, 500);
		setLocation(MyFunctions.getCenterLocation(this));
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if (e.getSource() == btn_DuplicateCheck) {
			
		} else if (e.getSource() == btn_SignUp) {
			
		} else if (e.getSource() == btn_Cancel) {
			dispose();
		}
		
	}
	
}
