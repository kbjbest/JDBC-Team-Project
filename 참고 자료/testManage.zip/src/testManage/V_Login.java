package testManage;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import aht.MyFunctions;

@SuppressWarnings("serial")
public class V_Login extends JFrame implements ActionListener {

	private M_DAO_Login_SignUp dao_Login;
	
	private JPanel pan_Input, pan_Button;
	private JTextField tf_Id;
	private JPasswordField pf_Pw;
	private JButton btn_Login, btn_SignUp, btn_Exit;
	
	public V_Login() {
		// TODO Auto-generated constructor stub
		super();
		Container container = getContentPane();
		container.setLayout(new FlowLayout(FlowLayout.CENTER, 13, 13));
		
		pan_Input = new JPanel(new GridLayout(2, 1));
		
		JPanel pan_Input_Id = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		pan_Input_Id.add(new JLabel("���̵�"));
		pan_Input_Id.add(tf_Id = new JTextField(10));
		
		JPanel pan_Input_Pw = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		pan_Input_Pw.add(new JLabel("��й�ȣ"));
		pan_Input_Pw.add(pf_Pw = new JPasswordField(10));
		
		pan_Input.add(pan_Input_Id);
		pan_Input.add(pan_Input_Pw);
		
		pan_Button = new JPanel(new BorderLayout(10, 10) );
		
		JPanel pan_Button_South = new JPanel(new GridLayout(1, 2, 10, 10));
		pan_Button_South.add(btn_SignUp = new JButton("ȸ������"));
		pan_Button_South.add(btn_Exit = new JButton("����"));
		
		pan_Button.add(btn_Login = new JButton("�α���"), BorderLayout.CENTER);
		pan_Button.add(pan_Button_South, BorderLayout.SOUTH);
		
		container.add(pan_Input);
		container.add(MyFunctions.spacePanel(200, 1, null));
		container.add(pan_Button);
		
		btn_Login.addActionListener(this);
		btn_SignUp.addActionListener(this);
		btn_Exit.addActionListener(this);
		
		setTitle("�α���");
		setSize(250, 220);
		setLocation(MyFunctions.getCenterLocation(this));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if (e.getSource() == btn_Login) {
			if (tf_Id.getText().isEmpty()) { // ���̵� ������� ��
				JOptionPane.showMessageDialog(this, "���̵� �Է����ּ���.", "���̵� ����", JOptionPane.ERROR_MESSAGE);
				tf_Id.requestFocus();
				
			} else if (pf_Pw.getPassword().length == 0) { // ��й�ȣ�� ������� ��
				JOptionPane.showMessageDialog(this, "��й�ȣ�� �Է����ּ���.", "��й�ȣ ����", JOptionPane.ERROR_MESSAGE);
				pf_Pw.requestFocus();
				
			} else { // ���̵�� ��й�ȣ �׸��� ��� ���� ���� ��
				dao_Login = new M_DAO_Login_SignUp();
				boolean isLogin = dao_Login.checkUser(tf_Id.getText(), String.valueOf(pf_Pw.getPassword()));
				
				if (isLogin) { // �α��� ����
					MainClass.myInfo = dao_Login.getUserInfo();
					JOptionPane.showMessageDialog(this, MainClass.myInfo.getId() + "��, ȯ���մϴ�!", "�α��� ����", JOptionPane.INFORMATION_MESSAGE);
					MainClass.showMain();
					setVisible(false);
					dispose();
					
				} else { // �α��� ����
					JOptionPane.showMessageDialog(this, "���̵�� ��й�ȣ�� ���� �ʽ��ϴ�.", "�α��� ����", JOptionPane.ERROR_MESSAGE);
				}
			}
			
		} else if (e.getSource() == btn_SignUp) {
			MainClass.showSignUp(this);
			
		} else if (e.getSource() == btn_Exit) {
			System.exit(0);
		}
	}

	public M_DTO getUserInfo() {
		return dao_Login.getUserInfo();
	}
	
}
